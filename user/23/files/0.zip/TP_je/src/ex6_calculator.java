import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.TextField;

import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ex6_calculator extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	double num1;
	double num2;
	double res;
	String operation;
	String txt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ex6_calculator frame = new ex6_calculator();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ex6_calculator() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 362, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(70, 130, 180));
		contentPane.setBorder(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button1 = new JButton("1");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String txt = textField.getText() + button1.getText(); 
				textField.setText(txt);	

			}
		});
		button1.setBorder(null);
		button1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button1.setBounds(36, 206, 50, 35);
		contentPane.add(button1);
		
		JButton button0 = new JButton("0");
		button0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String txt = textField.getText() + button0.getText(); 
				textField.setText(txt);			}
		});
		button0.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
			}
		});
		button0.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button0.setBorder(null);
		button0.setBounds(36, 262, 50, 35);
		contentPane.add(button0);
		
		JButton button4 = new JButton("4");
		button4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String txt = textField.getText() + button4.getText(); 
				textField.setText(txt);	
			}
		});
		button4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button4.setBorder(null);
		button4.setBounds(36, 147, 50, 35);
		contentPane.add(button4);
		
		JButton button7 = new JButton("7");
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt = textField.getText() + button7.getText(); 
				textField.setText(txt);	
			}
		});
		button7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button7.setBorder(null);
		button7.setBounds(36, 85, 50, 35);
		contentPane.add(button7);
		
		JButton button8 = new JButton("8");
		button8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt = textField.getText() + button8.getText(); 
				textField.setText(txt);	
			}
		});
		button8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button8.setBorder(null);
		button8.setBounds(112, 85, 50, 35);
		contentPane.add(button8);
		
		JButton button9 = new JButton("9");
		button9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt = textField.getText() + button9.getText(); 
				textField.setText(txt);	
			}
		});
		button9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button9.setBorder(null);
		button9.setBounds(178, 85, 50, 35);
		contentPane.add(button9);
		
		JButton buttondivide = new JButton("/");
		buttondivide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num1=Double.parseDouble(textField.getText());
				operation="/";
				textField.setText(null);
			}
		});
		buttondivide.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttondivide.setBorder(null);
		buttondivide.setBounds(251, 85, 50, 35);
		contentPane.add(buttondivide);
		
		JButton button5 = new JButton("5");
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String txt = textField.getText() + button5.getText(); 
				textField.setText(txt);	
			}
		});
		button5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button5.setBorder(null);
		button5.setBounds(112, 147, 50, 35);
		contentPane.add(button5);
		
		JButton button6 = new JButton("6");
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt = textField.getText() + button6.getText(); 
				textField.setText(txt);	
			}
		});
		button6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button6.setBorder(null);
		button6.setBounds(178, 147, 50, 35);
		contentPane.add(button6);
		
		JButton buttonmultiply = new JButton("*");
		buttonmultiply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num1=Double.parseDouble(textField.getText());
				operation="*";
				textField.setText(null);
			}
		});
		buttonmultiply.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttonmultiply.setBorder(null);
		buttonmultiply.setBounds(251, 147, 50, 35);
		contentPane.add(buttonmultiply);
		
		JButton button2 = new JButton("2");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String txt = textField.getText() + button2.getText(); 
				textField.setText(txt);	
			}
		});
		button2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button2.setBorder(null);
		button2.setBounds(112, 206, 50, 35);
		contentPane.add(button2);
		
		JButton button3 = new JButton("3");
		button3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String txt = textField.getText() + button3.getText(); 
				textField.setText(txt);	
			}
		});
		button3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		button3.setBorder(null);
		button3.setBounds(178, 206, 50, 35);
		contentPane.add(button3);
		
		JButton buttonminus = new JButton("-");
		buttonminus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num1=Double.parseDouble(textField.getText());
				operation="-";
				textField.setText(null);
			}
		});
		buttonminus.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttonminus.setBorder(null);
		buttonminus.setBounds(251, 206, 50, 35);
		contentPane.add(buttonminus);
		
		JButton buttonpoint = new JButton(".");
		buttonpoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt = textField.getText() + buttonpoint.getText(); 
				textField.setText(txt);	
			}
		});
		buttonpoint.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttonpoint.setBorder(null);
		buttonpoint.setBounds(112, 262, 50, 35);
		contentPane.add(buttonpoint);
		
		JButton buttonequal = new JButton("=");
		buttonequal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num2=Double.parseDouble(textField.getText());
				if(operation=="+") {
					res=num1+num2;
					txt=String.format("%.2f", res);
					textField.setText(txt);
				}
				if(operation=="-") {
					res=num1-num2;
					txt=String.format("%.2f", res);
					textField.setText(txt);
				}
				if(operation=="*") {
					res=num1*num2;
					txt=String.format("%.2f", res);
					textField.setText(txt);
				}
				if(operation=="/") {
					res=num1/num2;
					txt=String.format("%.2f", res);
					textField.setText(txt);
				}
			}
		});
		buttonequal.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttonequal.setBorder(null);
		buttonequal.setBounds(178, 262, 50, 35);
		contentPane.add(buttonequal);
		
		JButton buttonadd = new JButton("+");
		buttonadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					num1=Double.parseDouble(textField.getText());
					operation="+";
					textField.setText(null);
			}
		});
		buttonadd.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttonadd.setBorder(null);
		buttonadd.setBounds(251, 262, 50, 35);
		contentPane.add(buttonadd);
		
		textField = new JTextField();
		textField.setBounds(36, 22, 265, 35);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton buttonclear = new JButton("C");
		buttonclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(null);
			}
		});
		buttonclear.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttonclear.setBorder(null);
		buttonclear.setBounds(178, 308, 50, 35);
		contentPane.add(buttonclear);
		
		JButton buttonback = new JButton("<-");
		buttonback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(textField.getText().length()>0) {
					StringBuilder sb = new StringBuilder(textField.getText());
					sb.deleteCharAt(textField.getText().length()-1);
					buttonback=sb.toString();
					textField.setText(sb);
				}
				
				
			}
		});
		buttonback.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttonback.setBorder(null);
		buttonback.setBounds(251, 308, 50, 35);
		contentPane.add(buttonback);
	}
}
