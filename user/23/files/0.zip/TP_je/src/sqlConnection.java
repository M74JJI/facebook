import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.*;
import java.sql.*;


public class sqlConnection {

	
	
	 Connection cnx=null;
	
	public static Connection sqlcnx() {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection cnx=DriverManager.getConnection("jdbc:mysql://localhost/login", "root", "");
			
			
			return cnx;
			
			
			
		} catch (Exception e) {
			
			JOptionPane.showMessageDialog(null, "Login failed");
			return null;
		}
		
		
	}
	
}
