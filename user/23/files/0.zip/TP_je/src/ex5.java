import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.SystemColor;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;

public class ex5 extends JFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ex5 frame = new ex5();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ex5() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 645, 504);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("food1");
		chckbxNewCheckBox.setBounds(54, 69, 70, 23);
		panel.add(chckbxNewCheckBox);
		
		JCheckBox chckbxFood = new JCheckBox("food2");
		chckbxFood.setBounds(54, 107, 70, 23);
		panel.add(chckbxFood);
		
		JCheckBox chckbxFood_1 = new JCheckBox("food3");
		chckbxFood_1.setBounds(54, 151, 70, 23);
		panel.add(chckbxFood_1);
		
		JCheckBox chckbxFood_2 = new JCheckBox("food4");
		chckbxFood_2.setBounds(54, 196, 70, 23);
		panel.add(chckbxFood_2);
		
		JCheckBox chckbxFood_3 = new JCheckBox("food5");
		chckbxFood_3.setBounds(54, 248, 70, 23);
		panel.add(chckbxFood_3);
		
		JCheckBox chckbxFood_4 = new JCheckBox("food6");
		chckbxFood_4.setBounds(211, 69, 70, 23);
		panel.add(chckbxFood_4);
		
		JCheckBox chckbxFood_5 = new JCheckBox("food7");
		chckbxFood_5.setBounds(211, 107, 70, 23);
		panel.add(chckbxFood_5);
		
		JCheckBox chckbxFood_6 = new JCheckBox("food8");
		chckbxFood_6.setBounds(211, 151, 70, 23);
		panel.add(chckbxFood_6);
		
		JCheckBox chckbxFood_7 = new JCheckBox("food9");
		chckbxFood_7.setBounds(211, 196, 70, 23);
		panel.add(chckbxFood_7);
		
		JCheckBox chckbxFood_8 = new JCheckBox("food10");
		chckbxFood_8.setBounds(211, 248, 70, 23);
		panel.add(chckbxFood_8);
		
		JButton btnNewButton = new JButton("Select all");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				chckbxNewCheckBox.setSelected(true);
				chckbxFood.setSelected(true);
				chckbxFood_1.setSelected(true);
				chckbxFood_2.setSelected(true);
				chckbxFood_3.setSelected(true);
				chckbxFood_4.setSelected(true);
				chckbxFood_5.setSelected(true);
				chckbxFood_6.setSelected(true);
				chckbxFood_7.setSelected(true);
				chckbxFood_8.setSelected(true);
				
			}
		});
		btnNewButton.setBounds(405, 88, 89, 23);
		panel.add(btnNewButton);
		
		JButton btnDeselectAll = new JButton("Uncheck all");
		btnDeselectAll.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				chckbxNewCheckBox.setSelected(false);
				chckbxFood.setSelected(false);
				chckbxFood_1.setSelected(false);
				chckbxFood_2.setSelected(false);
				chckbxFood_3.setSelected(false);
				chckbxFood_4.setSelected(false);
				chckbxFood_5.setSelected(false);
				chckbxFood_6.setSelected(false);
				chckbxFood_7.setSelected(false);
				chckbxFood_8.setSelected(false);
				
			}
		});
		btnDeselectAll.setBounds(405, 166, 100, 23);
		panel.add(btnDeselectAll);
		
		JButton btnNewButton_1 = new JButton("Commande");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				btnNewButton_1.setMnemonic(KeyEvent.VK_E);
				
				JOptionPane.showMessageDialog(null,"");			
				
			}
		});
		btnNewButton_1.setBounds(416, 248, 89, 23);
		panel.add(btnNewButton_1);
		
		JButton btnExit = new JButton("exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnExit.setMnemonic(KeyEvent.VK_L);
				System.exit(0);
			}
			
		});
		btnExit.setBounds(416, 312, 89, 23);
		panel.add(btnExit);
	}
}
