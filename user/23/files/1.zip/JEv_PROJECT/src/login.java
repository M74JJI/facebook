import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import java.awt.Cursor;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 631, 439);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	   
		
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 894, 54);
		panel.setBackground(new Color(51, 255, 102));
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN PAGE");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Yu Gothic", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setBounds(30, 11, 231, 32);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1.setBounds(608, 9, 38, 37);
		panel.add(lblNewLabel_1);
		
		JLabel label = new JLabel("-");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				

			}
		});
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Tahoma", Font.BOLD, 29));
		label.setBounds(579, 6, 38, 37);
		panel.add(label);
		
		JPanel panel_1 = new JPanel();
		panel_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		panel_1.setForeground(SystemColor.text);
		panel_1.setBackground(new Color(0, 102, 153));
		panel_1.setBounds(0, 52, 631, 388);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Username");
		lblNewLabel_2.setForeground(SystemColor.text);
		lblNewLabel_2.setFont(new Font("Tw Cen MT", Font.ITALIC, 30));
		lblNewLabel_2.setBounds(45, 91, 147, 48);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Tw Cen MT", Font.ITALIC, 30));
		lblPassword.setBounds(45, 146, 147, 48);
		panel_1.add(lblPassword);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textField.setBackground(new Color(102, 153, 153));
		textField.setBounds(199, 102, 188, 29);
		panel_1.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		passwordField.setBackground(new Color(102, 153, 153));
		passwordField.setBounds(203, 157, 184, 29);
		panel_1.add(passwordField);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Show Password");
		chckbxNewCheckBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(chckbxNewCheckBox.isSelected()) {
					passwordField.setEchoChar((char)0);
				}else {
					passwordField.setEchoChar('*');
				}
			}
		});
		chckbxNewCheckBox.setBackground(new Color(0, 102, 153));
		chckbxNewCheckBox.setForeground(SystemColor.text);
		chckbxNewCheckBox.setFont(new Font("Trebuchet MS", Font.PLAIN, 12));
		chckbxNewCheckBox.setBounds(417, 164, 109, 23);
		panel_1.add(chckbxNewCheckBox);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBorderPainted(false);
		btnNewButton.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 18));
		btnNewButton.setBounds(298, 227, 99, 31);
		panel_1.add(btnNewButton);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setFont(new Font("Verdana", Font.BOLD | Font.ITALIC, 18));
		btnCancel.setBorderPainted(false);
		btnCancel.setBounds(162, 227, 109, 31);
		panel_1.add(btnCancel);
		
		JLabel lblNewLabel_3 = new JLabel("Click her if you want to create a new account");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				new signup().setVisible(true);
				
			}
		});
		lblNewLabel_3.setForeground(SystemColor.text);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(172, 307, 328, 14);
		panel_1.add(lblNewLabel_3);
	}
}
