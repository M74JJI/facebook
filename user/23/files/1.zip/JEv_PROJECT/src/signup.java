import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.mysql.cj.xdevapi.PreparableStatement;

import java.awt.Color;
import java.awt.Component;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.beans.PropertyChangeEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import java.awt.Dimension;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;

import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;

public class signup extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup frame = new signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signup() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 530, 650);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(70, 130, 180));
		contentPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setContentPane(contentPane);
		
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 530, 54);
		panel.setLayout(null);
		panel.setBackground(new Color(51, 255, 102));
		
		JLabel lblSignUpPage = new JLabel("SIGN UP PAGE");
		lblSignUpPage.setForeground(Color.WHITE);
		lblSignUpPage.setFont(new Font("Yu Gothic", Font.BOLD | Font.ITALIC, 25));
		lblSignUpPage.setBounds(30, 11, 231, 32);
		panel.add(lblSignUpPage);
		
		JLabel lblNewLabel = new JLabel("X");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel.setForeground(SystemColor.text);
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 23));
		lblNewLabel.setBounds(506, 14, 14, 28);
		panel.add(lblNewLabel);
		
		JLabel lblNom = new JLabel("Nom");
		lblNom.setBounds(25, 65, 147, 48);
		lblNom.setForeground(Color.WHITE);
		lblNom.setFont(new Font("Tw Cen MT", Font.ITALIC, 30));
		
		textField = new JTextField();
		textField.setBounds(179, 76, 188, 29);
		textField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textField.setColumns(10);
		textField.setBackground(new Color(245, 245, 245));
		
		JLabel lblPrenom = new JLabel("Prenom");
		lblPrenom.setBounds(25, 124, 147, 48);
		lblPrenom.setForeground(Color.WHITE);
		lblPrenom.setFont(new Font("Tw Cen MT", Font.ITALIC, 30));
		
		textField_1 = new JTextField();
		textField_1.setBounds(179, 135, 188, 29);
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textField_1.setColumns(10);
		textField_1.setBackground(new Color(245, 245, 245));
		
		JLabel label_2 = new JLabel("Username");
		label_2.setBounds(25, 183, 147, 48);
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Tw Cen MT", Font.ITALIC, 30));
		
		textField_2 = new JTextField();
		textField_2.setBounds(179, 194, 188, 29);
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textField_2.setColumns(10);
		textField_2.setBackground(new Color(245, 245, 245));
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(25, 242, 147, 48);
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Tw Cen MT", Font.ITALIC, 30));
		
		JLabel lblRetypePassword = new JLabel("Retype Pass");
		lblRetypePassword.setBounds(25, 301, 147, 48);
		lblRetypePassword.setForeground(Color.WHITE);
		lblRetypePassword.setFont(new Font("Tw Cen MT", Font.ITALIC, 30));
		contentPane.setLayout(null);
		contentPane.add(panel);
		contentPane.add(lblNom);
		contentPane.add(textField);
		contentPane.add(lblPrenom);
		contentPane.add(textField_1);
		contentPane.add(label_2);
		contentPane.add(textField_2);
		contentPane.add(lblPassword);
		contentPane.add(lblRetypePassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(179, 253, 188, 29);
		contentPane.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(179, 307, 188, 29);
		contentPane.add(passwordField_1);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Show Pass");
		chckbxNewCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 13));
		chckbxNewCheckBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(chckbxNewCheckBox.isSelected()) {
					passwordField.setEchoChar((char)0);
					passwordField_1.setEchoChar((char)0);
				}else {
					passwordField.setEchoChar('*');
					passwordField_1.setEchoChar('*');
				}
			}
		});
		chckbxNewCheckBox.setBackground(new Color(70, 130, 180));
		chckbxNewCheckBox.setBounds(385, 310, 89, 23);
		contentPane.add(chckbxNewCheckBox);
		
		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		btnNewButton_1.setBounds(200, 465, 98, 42);
		contentPane.add(btnNewButton_1);
		
		JButton button = new JButton("Sign Up");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Connection con = myConnection.getConnection();
				PreparedStatement ps;
				try {
					ps=con.prepareStatement("INSERT INTO `user`(`nom`, `prenom`, `username`, `password`) VALUES (?,?,?,?)");
					ps.setString(1, textField.getText());
					ps.setString(2, textField_1.getText());
					ps.setString(3, textField_2.getText());
					ps.setString(4, String.valueOf(passwordField));
					
					if(ps.executeUpdate() != 0) {
						JOptionPane.showMessageDialog(null, "Account Created");
					}else {
						JOptionPane.showMessageDialog(null, "Error Creating Account");
					}
					
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
			}
		});
		button.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		button.setBounds(330, 465, 98, 42);
		contentPane.add(button);
		
		JLabel lblNewLabel_1 = new JLabel("Login instead ?");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new login().setVisible(true);
			}
		});
		lblNewLabel_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel_1.setForeground(SystemColor.text);
		lblNewLabel_1.setFont(new Font("Verdana", Font.ITALIC, 18));
		lblNewLabel_1.setBounds(253, 554, 188, 42);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(10, 406, 135, 116);
		contentPane.add(lblNewLabel_2);
	}
}
